#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Stack.h"
#include "Queue.h"

bool bal(char *);
bool hasHigherPrecedence(char * top, char * operator);
char * InfixToPosfix(char * exp);

int main(){
	setvbuf(stdout, NULL, _IONBF, 0);
	int v;
	char c[50];
	printf("Ecuacion:  ");
	gets(c);
	v = bal(c);
	if(v == false)
		printf("Ecuacion incorrecta");
	else
		printf("Ecuancion correcta");
	char cadInfijo[30];
	char cadPostfijo[50];
	printf("\nIntroduce la expresion matematica: ");
	gets(cadInfijo);
	strcpy(cadPostfijo, InfixToPosfix(cadInfijo));
	printf("\nEn cadena posfijo es: ");
	puts(cadPostfijo);
	return 0;
}

bool bal(char* x){
	Stack s1;
	char* letraPop;
	s1=createStack();
	if (s1==NULL){
		return false;
	}
	int i;
	for (i=0; x[i] != '\0'; i++){
		if (x[i]=='(')
			push(s1, (void *)&x[i]);
		else if (x[i]=='[')
			push(s1, (void *)&x[i]);

		else if ( x[i] == ')' ){
			letraPop = (char *)pop(s1);
			if (*letraPop != '('){
				return false;
			}
		}
		else if(x[i]==']'){
			letraPop = (char *)pop(s1);
			if (*letraPop != '['){
				return false;
			}
		}
	}
	if (isEmpty(s1)==true)
		return true;
	else{
		return false;
	}
}


bool hasHigherPrecedence(char * top, char * operator){
		if(	(*top == '*' || *top == '/') && (*operator == '-' || *operator == '+') )
			return true;
		else
			return false;
	}

char * InfixToPosfix(char * exp){
	Stack pila = NULL;
	Queue colaFin = NULL, auxCola = NULL;
	char *topData;
	auxCola = create_queue();
	colaFin = create_queue();
	pila = createStack();
	int *temp;
	int i;
	for(i=0; i!='\0'; i++){
		offer_queue(auxCola, &exp[i] );
		temp = peek_queue(auxCola);
	}
	char *caracter;
	for(i=0; i!='\0'; i++){
		caracter = poll_queue(auxCola);
		if (*caracter == '('){
			offer_queue(colaFin,caracter);
		}
		else if(*caracter == '+' || *caracter == '-' || *caracter == '*' || *caracter == '/'){
			topData = top(pila);
			while(  (isEmpty(pila) == false) && ( *topData != '(')  ){
				if(hasHigherPrecedence(topData , caracter ) == true){
					offer_queue(colaFin,top(pila));
				}
				else {
					goto rompeciclos;
					}
			}
			rompeciclos:
			push(pila, caracter);
			topData = top(pila);
		}
		else if(*caracter== ')'){
			while(  (isEmpty(pila) == false) && ( *topData != '(')  ){
				offer_queue(colaFin,top(pila));
			}
			if(isEmpty(pila) == false){
				top(pila);
			}
		}
//a)
		else {
			offer_queue(colaFin,caracter);
		}
	}
	while(isEmpty(pila) == false){
		temp = pop(pila);
		offer_queue(colaFin, temp );
	}
	char cad1[40];
	i=0;
	while (isEmptyQueue(colaFin) == 0){
		temp = poll_queue(colaFin);
		cad1[i] = *temp;
		cad1[i+1] = ' ';
		i+=2;
	}

	char *res = cad1;

	return res;
}
